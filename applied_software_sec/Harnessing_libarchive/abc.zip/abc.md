# Task 1: Industrial Control System Capture-the-Flag Exercises

## CTF-1: Attacking ICS Plant #1

### Task 1: Introduction to OT/ICS
No answer needed

### Task 2: Introduction to Modbus protocol
- Function for reading holding registers in pymodbus library: `read_holding_registers`
- Function for writing holding registers in pymodbus library: `write_register`

### Task 3: Discovery
- Phases observed: 3
- Sensors observed: 2
- Actuators observed: 3
- Discovery.py script registers count: 16
- Continuously changing registers after plant start and bottle load: 4
- Minimum observed value: 0
- Maximum observed value: 1
- Registry holding its value: 16
- Registries set to 1 while nozzle is filling a bottle: 2, 4
- Registries set to 1 while roller is moving the bottles: 1, 3
- Water level sensor color: red
- Bottle sensor color: green
- Registry associated with the roller at the beginning: 3
- Registry associated with the water level sensor based on previous answer: 1

### Task 4: Play to learn
- Registry associated with the nozzle: 4

### Task 5: Attack
No answer needed for the specified actions.

## CTF-2: Attacking ICS Plant #2

### Task 1: Discovery
No answer needed

### Task 2: Flag #1
Read flag1.txt: `0df2936b4cfbd5ce3ae91ef7021d925a`

### Task 3: Flag #2
Read flag2.txt: `fdee450ac6627276d115dd905a256d49`

# Reflection Part

**Question:** What is the fundamental vulnerability of these systems that you are exploiting, and how would you mitigate this vulnerability in the real world?

**Answer:**
- **Vulnerability:** The openness of the Plant's Network to the outside network. Lack of authentication for script execution.
- **Mitigation:**
  - Implement access/authentication protocols for script execution.
  - Keep software and firmware up-to-date with security patches.
  - Install a firewall or network intrusion detector.

# Task 2: Monitoring STL Properties of the ICS Traces

## Trace files:
- Benign: traces.txt
- Malicious:
  - traces_attack_move_fill2.txt (based on attack_move_fill2.py)
  - traces_attack_shutdown2.txt (based on attack_shutdown2.py)

## Monitor files:
- samplemonitor.py: Contains functions to calculate robustness for benign trace file specs.
- anomaltmonitor.py: Contains a function to calculate robustness for spec2 from malicious trace files.

### Monitoring the benign trace file (samplemonitor.py)
- Robustness of spec1: [[0, -0.0], [57.940584897994995, -1.0], [58.65449070930481, -1.0]]
  - Opinion: First robustness seems incorrect.

- Robustness of spec2: [[0.15729808807373047, 0.0], [58.81263589859009, 1.0], [59.5265417098999, 1.0]]
  - Opinion: Robustness changes from 0.0 to 1.0 at 58.81263589859009 timestamp.

- Robustness of spec3: [[0.15729808807373047, 0.0], [59.5265417098999, 0.0]]
  - Opinion: No change in robustness.

- Robustness of spec4: [[0.15729808807373047, 1.0], [59.5265417098999, 1.0]]
  - Opinion: No change in robustness.

### Monitoring traces_attack_move_fill2.txt for spec2 (anomalymonitor.py)
- Robustness of spec2: [[0.15912604331970215, 1.0], [59.87752914428711, 1.0]]
  - Opinion: No change in robustness.

### Monitoring traces_attack_shutdown2.txt for spec2 (anomalymonitor.py)
- Robustness of spec2: [[0.15818214416503906, 0.0], [13.705410718917847, 1.0], [59.502843141555786, 1.0]]
  - Opinion: Robustness changes from 0.0 to 1.0 at 13.705410718917847 timestamp.

# Task 3: Build Your First PLC Program
